USE [rossini-dev]

CREATE TABLE [Jogos] 
(
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Nome] NVARCHAR (15) NOT NULL,
    [Produtora] NVARCHAR (15) NOT NULL,
    [Preco] MONEY NOT NULL,

    CONSTRAINT [PK_Jogos] PRIMARY KEY ([Id])
)